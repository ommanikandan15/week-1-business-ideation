# Research Sources — Week 1

This file documents the public sources used to support the market and industry analysis in the Week 1 report.

> **Research note:** Market estimates from commercial research organizations can differ because of definitions, data sources and forecast methodologies. Figures are therefore treated as directional market evidence, not guaranteed outcomes.

---

## 1. Higher Education — India

**Source:** Ministry of Education, Government of India  
**Document:** Annual Report 2024–25  
**URL:** https://www.education.gov.in/sites/upload_files/mhrd/files/document-reports/MoE_AR_En.pdf

**Used for:**  
- India's higher-education enrolment
- Higher-education ecosystem context

**Key evidence used in report:**  
India's higher-education enrolment was nearly 4.46 crore in 2022–23.

---

## 2. Graduate Employability & Skills

**Source:** Mercer | Mettl  
**Report:** India's Graduate Skill Index 2025  
**URL:** https://www.mercer.com/insights/talent-and-transformation/talent-assessment/indias-graduate-skill-index-2025/

**Used for:**  
- Graduate employability
- AI/ML readiness
- Skills-gap context

**Key evidence used in report:**  
The report assessed more than one million students across 2,700+ campuses and reported 42.6% overall graduate employability and 46.1% readiness for AI/ML roles.

---

## 3. AI / ML Hiring Trends

**Source:** Naukri  
**Report:** Naukri JobSpeak — June 2026  
**URL:** https://www.naukri.com/blog/naukri-jobspeak-white-collar-hiring-grows-6-in-june-2026-ai-ml-and-fresher-hiring-lead-the-charge/

**Used for:**  
- AI/ML hiring momentum
- Indian white-collar hiring context

**Key evidence used in report:**  
The June 2026 report stated that AI/ML roles grew 25% year over year.

---

## 4. Indian Education & EdTech Market

**Source:** India Brand Equity Foundation (IBEF)  
**Page:** Education Industry in India  
**URL:** https://www.ibef.org/industry/education-presentation

**Used for:**  
- Indian education market context
- Edtech market direction
- Digital education growth

---

## 5. Indian EdTech Market — Alternative Industry Estimate

**Source:** India Brand Equity Foundation (IBEF)  
**Article:** India's Edtech Market  
**URL:** https://www.ibef.org/news/india-s-edtech-market-likely-to-reach-rs-2-50-850-crore-us-29-billion-by-2030-report

**Used for:**  
- Additional edtech market context
- Long-term growth expectations

**Note:** This is a secondary industry estimate and should not be combined mechanically with other market forecasts.

---

## 6. E-Waste — Regulatory / EPR Context

**Source:** Ministry of Environment, Forest and Climate Change (MoEFCC), Government of India  
**Document:** Technical Review Committee material  
**URL:** https://www.moef.gov.in/uploads/2024/03/Decision_of_85th_meeting_TRC.pdf

**Used for:**  
- EPR ecosystem
- Registered recycler / producer context
- Formal e-waste management framework

---

## 7. E-Waste Market — Industry Research

**Source:** Mordor Intelligence  
**Page:** India E-Waste Management Market  
**URL:** https://www.mordorintelligence.com/industry-reports/india-e-waste-management-market

**Used for:**  
- E-waste generation context
- Competitive landscape
- Market-development context

**Key evidence used in report:**  
The source cites India generating approximately 3.8 million tonnes of e-waste in FY24 and identifies major industry participants.

**Important:** This is an industry-research source, not a government statistical release.

---

## 8. E-Waste Collection / Responsible Recycling Example

**Source:** Cashify  
**Page:** E-Waste Policy  
**URL:** https://www.cashify.in/e-waste-policy

**Used for:**  
- Example of formal e-waste collection and recycling practices
- Competitive / industry context

---

## 9. Energy Efficiency Market — India

**Source:** Bureau of Energy Efficiency (BEE), Government of India  
**Page:** Energy Efficiency Services / Market Context  
**URL:** https://beeindia.gov.in/show_content.php?lang=1&level=3&lid=29&ls_id=169

**Used for:**  
- Energy-efficiency market opportunity
- ESCO model context
- Market barriers

**Key evidence used in report:**  
BEE estimates India's energy-efficiency market at approximately ₹74,000 crore and discusses the limited penetration of the ESCO model on the cited page.

---

## 10. India Energy Scenario

**Source:** Bureau of Energy Efficiency (BEE), Government of India  
**Report:** India Energy Scenario 2024–25  
**URL:** https://beeindia.gov.in/sites/default/files/India_Energy_Scenario_Report_2024-25.pdf

**Used for:**  
- Energy-efficiency savings
- Avoided-cost context
- National energy-efficiency programme evidence

---

## 11. MSME Ecosystem

**Source:** Ministry of Micro, Small & Medium Enterprises, Government of India  
**Dashboard:** MSME Dashboard  
**URL:** https://dashboard.msme.gov.in/

**Used for:**  
- MSME ecosystem context
- Reference point for further primary/secondary market research

---

## 12. Career-Tech Competitive Context

**Source:** Naukri  
**Platform:** Naukri360  
**URL:** https://www.naukri.com/naukri360

**Used for:**  
- Existing career-tech functionality
- AI-assisted resume / interview preparation context
- Competitive analysis

---

## Research Method

The report used the following process:

1. Identify an emerging market trend.
2. Define the customer problem.
3. Find public evidence supporting the broader market context.
4. Identify existing competitors and substitutes.
5. Evaluate strengths, weaknesses, opportunities and threats.
6. Assess feasibility and scalability.
7. Define a customer-validation experiment.
8. Avoid treating secondary market forecasts as guaranteed demand.

## Citation / Attribution Principle

External statistics and factual claims should remain attributed to their original sources. The business concepts, strategic interpretation, SWOT assessments and validation hypotheses in the project are analytical work created for this submission.
