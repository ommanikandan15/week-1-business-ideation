# Presentation

Place the Week 1 pitch deck / presentation in this folder.

Recommended filename:

`Week_1_Business_Ideation_Presentation.pptx`

Suggested presentation flow:

1. Title
2. Problem / opportunity
3. Three business ideas
4. Idea 1 — CareerPilot AI
5. Idea 2 — E-Waste Passport
6. Idea 3 — EnergyPilot MSME
7. Market evidence
8. Competitive landscape
9. SWOT comparison
10. Recommended concept
11. MVP
12. Validation plan
13. Business model
14. 90-day roadmap
15. Conclusion
