# Assets

Store supporting visual material here.

Examples:

- Market charts
- Business-model diagrams
- SWOT visuals
- Product mockups
- Pitch banner
- Screenshots
- Research figures

Recommended naming convention:

`idea1-careerpilot-market.png`
`idea2-ewaste-swot.png`
`idea3-energypilot-market.png`
